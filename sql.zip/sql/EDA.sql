select*
from customers_clean2;

select*
from products_clean2;

select*
from orders_clean2;

select*
from order_items_clean2;

-----------------------------------------------------------------------------------------------------------------
-- Sales Overview

-- Total Revenue

 select sum(quantity * unit_price) as Total_Revenue
 from order_items_clean2;
 
 -- Total Orders
 
 select count(distinct order_id) as Total_Orders
 from orders_clean2;
 
 -- Average Order Value
 
 select avg(Each_Order_Value) as Average_Order_Value
 from(
 select order_id, sum(quantity * unit_price) as Each_Order_Value
 from order_items_clean2
 group by order_id) as s;
 
 ------------------------------------------------------------------------------------------------------------------------------
 
 -- Customer Behaviour
 
 -- Total Customers
 
 select count(distinct customer_id) as Total_Customers
 from customers_clean2;
 
 -- Top 10 Customers
 
 select c.customer_id , c.customer_name, sum(oi.quantity * oi.unit_price) as Total_Spend
 from customers_clean2 as c
 join orders_clean2 as o
 on c.customer_id = o.customer_id
 join order_items_clean2 as oi
 on o.order_id = oi.order_id
 group by customer_id , customer_name
 order by Total_Spend Desc
 Limit 10;
 
-- Total Orders By Each Customer
 
 select customer_id, count(order_id) as Total_Orders_by_Customer
 from orders_clean2
 group by customer_id
 order by 2 Desc;
 
 -------------------------------------------------------------------------------------------------------------------
 
 -- Product Analysis
 
 -- Best Selling Products by Quantity
 select p.product_id ,  p.product_name , sum(oi.quantity) as Total_Quantity
 from products_clean2 p
 join order_items_clean2 oi
on p.product_id = oi.product_id
group by p.product_id ,  p.product_name
order by 3 Desc
limit 10;

-- Categories by Revenue
select p.category ,   sum(oi.quantity * oi.unit_price) as Total_Revenue
from products_clean2 p
join order_items_clean2 oi
on p.product_id = oi.product_id
group by p.category 
order by 2 Desc;


-- Least Selling Products
 select p.product_id ,  p.product_name , sum(oi.quantity) as Total_Quantity
 from products_clean2 p
 join order_items_clean2 oi
on p.product_id = oi.product_id
group by p.product_id ,  p.product_name
order by 3 asc
limit 10;

-----------------------------------------------------------------------------------
-- Time Based Analysis

-- Monthly Sales
select date_format(o.order_date ,'%Y-%m' ) as Months ,sum(oi.quantity * oi.unit_price) as Total_Revenue
from orders_clean2 o 
join order_items_clean2 oi
on o.order_id = oi.order_id
group by Months
order by 1;

-- Daily Sales
select o.order_date ,sum(oi.quantity * oi.unit_price) as Total_Revenue
from orders_clean2 o 
join order_items_clean2 oi
on o.order_id = oi.order_id
group by o.order_date
order by 1;

-- Peak Days
select o.order_date ,sum(oi.quantity * oi.unit_price) as Total_Revenue
from orders_clean2 o 
join order_items_clean2 oi
on o.order_id = oi.order_id
group by o.order_date
order by 2 desc
limit 10 ;
 
 
 

