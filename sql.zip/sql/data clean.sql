select*
from customers;

create table customers_clean
like customers;

select*
from customers_clean;

insert into customers_clean
select*
from customers;

select* , row_number() over(partition by customer_id , customer_name, country , gender, signup_date) as dup_check
from customers_clean;

with duplicate_cte as
(
select* , row_number() over(partition by customer_id , customer_name, country , gender, signup_date) as dup_check
from customers_clean
)
select*
from duplicate_cte
where dup_check > 1 ;


CREATE TABLE `customers_clean2` (
  `customer_id` int DEFAULT NULL,
  `customer_name` text,
  `country` text,
  `gender` text,
  `signup_date` text,
  `dup_check` int
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


insert into customers_clean2
select* , row_number() over(partition by customer_id , customer_name, country , gender, signup_date) as dup_check
from customers_clean;

select*
from customers_clean2;

delete
from customers_clean2
where dup_check>1;

select country
from customers_clean2
group by country;

delete
from customers_clean2
where country regexp '[0-9]';


select*
from customers_clean2;


update customers_clean2
set signup_date = str_to_date(signup_date,'%Y-%m-%d');


alter table customers_clean2
modify column signup_date date;

select*
from customers_clean2;

update customers_clean2
set customer_name = concat('Customer_',customer_id)
where customer_name= '' ;


select*
from customers_clean2;

alter table customers_clean2
drop column dup_check;

select*
from customers_clean2;

----------------------------------

select*
from products; 

create table products_clean
like products;

select*
from products_clean;

insert into products_clean
select*
from products;

select*
from products_clean;


select* , row_number() over(partition by product_id , product_name, category , price) as dup_check
from products_clean;

with duplicate_cte as
(
select* , row_number() over(partition by product_id , product_name, category , price) as dup_check
from products_clean
)
select*
from duplicate_cte
where dup_check > 1 ;

CREATE TABLE `products_clean2` (
  `product_id` int DEFAULT NULL,
  `product_name` text,
  `category` text,
  `price` double DEFAULT NULL,
  `dup_check` int
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

insert into products_clean2
select* , row_number() over(partition by product_id , product_name, category , price) as dup_check
from products_clean; 

select*
from products_clean2;

delete
from products_clean2
where dup_check>1;

select*
from products_clean2;

update products_clean2
set category = 'Uncategorized' 
where category = '' ; 

select*
from products_clean2;

select  price , category 
from products_clean2
where  price < 0 ;

select category , avg(price) as avg_price
from products_clean2
where price >= 0
group by category;
 
update products_clean2 p
join(
select category , avg(price) as avg_price
from products_clean2
where price >= 0
group by category
    )avg_prices
on p.category = avg_prices.category
set p.price = avg_prices.avg_price
where p.price < 0;

select* 
from products_clean2;

alter table products_clean2
drop column dup_check;

-----------------------------------------------------------------------------------------------------

select*
from orders; 

create table orders_clean
like orders;

select*
from orders_clean;

insert into orders_clean
select*
from orders;

select*
from orders_clean;


select* , row_number() over(partition by order_id , customer_id, order_date , total_amount) as dup_check
from orders_clean;

with duplicate_cte as
(
select* , row_number() over(partition by order_id , customer_id, order_date , total_amount) as dup_check
from orders_clean
)
select*
from duplicate_cte
where dup_check > 1 ;

CREATE TABLE `orders_clean2` (
  `order_id` int DEFAULT NULL,
  `customer_id` int DEFAULT NULL,
  `order_date` text,
  `total_amount` double DEFAULT NULL,
   `dup_check` int
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


insert into orders_clean2
select* , row_number() over(partition by order_id , customer_id, order_date , total_amount) as dup_check
from orders_clean;

select*
from orders_clean2;

delete
from orders_clean2
where dup_check>1;

select*
from orders_clean2;

delete
from orders_clean2
where order_date = '';


update orders_clean2
set order_date = str_to_date(order_date , '%Y-%m-%d');


alter table orders_clean2
modify column order_date date;

select*
from orders_clean2;

alter table orders_clean2
drop column dup_check;

select*
from orders_clean2;
----------------------------------------------------------------

select*
from order_items;

create table order_items_clean
like order_items;

select*
from order_items_clean;

insert into order_items_clean
select*
from order_items;

select*
from order_items_clean;


select* , row_number() over(partition by item_id , order_id, product_id , quantity , unit_price) as dup_check
from order_items_clean;

with duplicate_cte as
(
select* , row_number() over(partition by item_id , order_id, product_id , quantity , unit_price) as dup_check
from order_items_clean
)
select*
from duplicate_cte
where dup_check > 1 ;

CREATE TABLE `order_items_clean2` (
  `item_id` int DEFAULT NULL,
  `order_id` int DEFAULT NULL,
  `product_id` double DEFAULT NULL,
  `quantity` double DEFAULT NULL,
  `unit_price` double DEFAULT NULL,
   `dup_check` int
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

insert into order_items_clean2
select* , row_number() over(partition by item_id , order_id, product_id , quantity , unit_price) as dup_check
from order_items_clean;

select*
from order_items_clean2;


select product_id
from order_items_clean2
where product_id not in (select product_id from products_clean2);


delete 
from order_items_clean2
where product_id = 9999;

select*
from order_items_clean2;

alter table order_items_clean2
drop column dup_check;

select*
from order_items_clean2;



